Tyler Feist
Lab #5
ECE 456

Simple File Transfer Protocol Program using Python and Geni

Instructions:

Server:
1) navigate to the directory with server.py in it via the command line on the server geni node
2) ensure the directory also contains helper.py and L1.py
3) server.py requires 1 command line argument: outFileName
4) run "python3 server.py <outFileName>"
5) the script will wait to receive a client message, the server will receive 1024 byte packets until the client closes the connection, it sends an OK response to each
6) it then asks the user whether or not they'd like to save the file

Client:
1) navigate to the directory with client.py in it via the command line on the client geni node
2) ensure the directory also contains helper.py, L1.py, and a file containing the message to be sent
3) client.py requires 2 command line arguments: serverIP, inFileName
4) run "python3 client.py <serverIP> <inFileName>"
5) the script will read data from <inFileName> 1024 bytes at a time and send them to the sever using TCP
